(function(){
 'use strict';
 const bridge=window.webkit?.messageHandlers?.hsk;if(!bridge)return;
 let state=window.__HSK_NATIVE_STATE__||{},applying=false,inflight=false,timer;
 let last=JSON.parse(JSON.stringify(state.storage||{})),sent=null;
 const realSet=Storage.prototype.setItem,realRemove=Storage.prototype.removeItem;
 function storage(){const x={};for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(k.startsWith('hsk-'))x[k]=localStorage.getItem(k);}return x;}
 function send(type,extra={}){bridge.postMessage({type,...extra});}
 function queue(){if(applying)return;clearTimeout(timer);timer=setTimeout(flush,80);}
 function flush(){if(inflight)return;const x=storage();if(Object.keys(x).length===Object.keys(last).length&&Object.keys(x).every(k=>x[k]===last[k]))return;inflight=true;sent=x;send('save',{storage:x,revision:state.revision||0});}
 Storage.prototype.setItem=function(k,v){realSet.call(this,k,v);if(this===localStorage&&String(k).startsWith('hsk-'))queue();};
 Storage.prototype.removeItem=function(k){realRemove.call(this,k);if(this===localStorage&&String(k).startsWith('hsk-'))queue();};
 function mergeProgress(base,current,incoming){
  try{const b=JSON.parse(base||'{}').words||{},c=JSON.parse(current||'{}').words||{},n=JSON.parse(incoming||'{}').words||{};
   for(const k of new Set([...Object.keys(b),...Object.keys(c)])){if(JSON.stringify(b[k])!==JSON.stringify(c[k])){if(c[k])n[k]=c[k];else delete n[k];}}
   return JSON.stringify({version:1,words:n});
  }catch{return incoming;}
 }
 window.hskNative={applyState(next){
  const current=storage(),base=sent||last,merged={...next.storage};
  for(const k of new Set([...Object.keys(base),...Object.keys(current)]))if(base[k]!==current[k]){
   if(k==='hsk-flashcards-progress-v1')merged[k]=mergeProgress(base[k],current[k],merged[k]);
   else if(current[k]!==undefined)merged[k]=current[k];else delete merged[k];
  }
  applying=true;
  for(const k of Object.keys(current))if(!(k in merged))realRemove.call(localStorage,k);
  for(const [k,v]of Object.entries(merged))realSet.call(localStorage,k,v);
  try{records=JSON.parse(merged[STORE_KEY]||'{"words":{}}').words||{};
   const a=JSON.parse(merged[ADAPTIVE_KEY]||'null');if(a?.stats){adaptiveState={enabled:a.enabled!==false,stats:a.stats};adaptiveScoreCache=null;}
   rebuildDeck(currentWords[index]);stats();refreshMemoryDashboard();if(mode==='srs'&&srsSession)renderSrs();
  }catch(e){console.error(e);}
  state=next;last={...next.storage};sent=null;inflight=false;applying=false;render();queue();
 }};
 const oldPush=document.querySelector('.push-settings');if(oldPush)oldPush.hidden=true;
 const panel=document.createElement('details');panel.className='push-settings';panel.open=true;
 panel.innerHTML='<summary>🔔 Simple Test trên màn hình khóa</summary><p class="hint">Chỉ ôn các từ bạn đã học/đánh dấu. Nhấn giữ thông báo → chọn Đúng hoặc Sai. Kết quả tự cập nhật lịch SRS, không cần mở app.</p><div class="field-row"><label>Giờ ôn <select id="nativeHour"></select></label><label>HSK <select id="nativeLevel"><option value="0">Tất cả HSK</option>'+[1,2,3,4,5,6].map(n=>'<option value="'+n+'">HSK '+n+'</option>').join('')+'</select></label></div><div class="field-row"><label>Số câu tối đa/ngày <select id="nativeLimit">'+[5,10,20,30].map(n=>'<option>'+n+'</option>').join('')+'</select></label></div><label class="hint"><input type="checkbox" id="nativeNext"> Gửi câu tiếp theo sau khi trả lời (nếu còn từ đến hạn)</label><div class="field-row"><button id="nativeEnable">Bật Simple Test</button><button id="nativeDisable">Tắt</button></div><button id="nativeTest">Thử thông báo sau 10 giây</button><p id="nativeStatus" role="status" class="hint"></p><p class="hint">Giờ theo điện thoại. Lịch được chuẩn bị cho 7 ngày tới và làm mới khi mở app hoặc trả lời thông báo. iOS có thể trì hoãn vì chế độ Tập trung hoặc cài đặt thông báo.</p><div class="field-row"><button id="nativeImport">Nhập tiến độ từ file</button><button id="nativeExport">Sao lưu tiến độ</button></div><details><summary>Lịch sử trả lời trên thông báo</summary><div id="nativeHistory"></div></details>';
 $('srsPanel').insertBefore(panel,$('srsPanel').children[1]);
 $('nativeHour').innerHTML=Array.from({length:24},(_,n)=>'<option value="'+n+'">'+String(n).padStart(2,'0')+':00</option>').join('');
 function render(){const s=state.settings||{};$('nativeHour').value=String(s.hour??20);$('nativeLevel').value=String(s.level??0);$('nativeLimit').value=String(s.limit??10);$('nativeNext').checked=s.nextAfterAnswer!==false;$('nativeStatus').textContent=state.error||state.message||(s.enabled?'Đang bật Simple Test.':'Chưa bật Simple Test.');$('nativeHistory').replaceChildren();
  for(const a of [...state.answers||[]].reverse()){const p=document.createElement('p');p.textContent=a.correct==='error'?a.gloss:(a.correct==='1'?'✓':'✗')+' '+a.han+' → '+a.gloss+' · Mệnh đề '+(a.truth==='1'?'đúng':'sai')+' · Nghĩa đúng: '+a.correctGloss;$('nativeHistory').append(p);}
 }
 function settings(){send('settings',{hour:Number($('nativeHour').value),level:Number($('nativeLevel').value),limit:Number($('nativeLimit').value),nextAfterAnswer:$('nativeNext').checked});}
 for(const id of ['nativeHour','nativeLevel','nativeLimit','nativeNext'])$(id).onchange=settings;
 for(const [id,type]of [['nativeEnable','enable'],['nativeDisable','disable'],['nativeTest','test'],['nativeImport','import'],['nativeExport','export']])$(id).onclick=()=>{flush();send(type);};
 render();send('ready');queue();
 document.addEventListener('visibilitychange',()=>{if(document.hidden)flush();});
})();
