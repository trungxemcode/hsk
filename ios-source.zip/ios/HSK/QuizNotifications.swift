import UIKit
import UserNotifications

final class QuizNotifications: NSObject, UNUserNotificationCenterDelegate {
    static let shared = QuizNotifications()
    let center = UNUserNotificationCenter.current()
    var words: [StudyWord] = []
    var stateChanged: (() -> Void)?
    private let store = StudyStore.shared
    func configure() {
        center.delegate = self
        if let url = Bundle.main.url(forResource: "notification-words", withExtension: "json"),
           let data = try? Data(contentsOf: url), let bank = try? JSONDecoder().decode([StudyWord].self, from: data) { words = bank }
        // Neither foreground nor authenticationRequired: answers are handled in the background.
        let yes = UNNotificationAction(identifier: "HSK_TRUE", title: "Đúng", options: [])
        let no = UNNotificationAction(identifier: "HSK_FALSE", title: "Sai", options: [])
        center.setNotificationCategories([UNNotificationCategory(identifier: "HSK_SIMPLE_TEST",
             actions: [yes, no], intentIdentifiers: [], options: [])])
    }
    func enable(completion: @escaping (String) -> Void) {
        center.requestAuthorization(options: [.alert, .sound, .badge]) { granted, error in
            DispatchQueue.main.async {
                self.store.state.settings.enabled = granted
                self.store.persist()
                self.reschedule()
                completion(error?.localizedDescription ?? (granted ? "Đã bật Simple Test trên thông báo." : "Chưa có quyền. Mở Cài đặt → Thông báo → HSK để bật."))
            }
        }
    }
    func disable() {
        store.state.settings.enabled = false; store.persist()
        center.removeAllPendingNotificationRequests(); center.removeAllDeliveredNotifications()
        store.state.questions = [:]; store.persist()
    }
    func add(_ question: QuizItem, after: TimeInterval, prefix: String = "", completion: ((Error?) -> Void)? = nil) {
        let content = UNMutableNotificationContent()
        content.title = "HSK \(question.hsk) · Đúng hay sai?"
        content.body = prefix + "\(question.han) (\(question.pin)) có nghĩa là “\(question.gloss)”.\nNhấn giữ thông báo → chọn Đúng hoặc Sai."
        content.sound = .default; content.categoryIdentifier = "HSK_SIMPLE_TEST"
        content.threadIdentifier = "hsk-simple-test"
        content.userInfo = ["questionID": question.id]
        store.state.questions[question.id] = question
        guard store.persist() else { completion?(NSError(domain: "HSK", code: 1, userInfo: [NSLocalizedDescriptionKey: store.lastError ?? "Không lưu được câu hỏi."])); return }
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: max(1, after), repeats: false)
        center.add(UNNotificationRequest(identifier: "hsk-" + question.id, content: content, trigger: trigger)) { error in
            if let error { DispatchQueue.main.async { self.store.lastNotificationError(error) } }
            completion?(error)
        }
    }
    func reschedule() {
        center.removeAllPendingNotificationRequests()
        // Keep delivered unanswered questions, so an older notification remains answerable.
        let settings = store.state.settings
        guard settings.enabled else { return }
        let now = Date(), calendar = Calendar.current
        var chosen = Set<String>()
        for offset in 0..<7 {
            guard let day = calendar.date(byAdding: .day, value: offset, to: now),
                  let fire = calendar.date(bySettingHour: settings.hour, minute: 0, second: 0, of: day), fire > now else { continue }
            if offset == 0 && (store.state.dailyCount[store.dayKey()] ?? 0) >= settings.limit { continue }
            let eligible = StudyCore.eligible(words: words, storage: store.state.storage, level: settings.level, at: fire.timeIntervalSince1970 * 1000)
            guard let word = eligible.first(where: { !chosen.contains($0.key) }) ?? eligible.first,
                  let q = StudyCore.question(word: word) else { continue }
            chosen.insert(word.key)
            add(q, after: fire.timeIntervalSince(now))
        }
        // Bound persisted payload history independently of the OS pending request limit.
        if store.state.questions.count > 150 {
            center.getDeliveredNotifications { delivered in
                DispatchQueue.main.async {
                    let keep = Set(delivered.compactMap { $0.request.content.userInfo["questionID"] as? String })
                    self.center.getPendingNotificationRequests { pending in
                        DispatchQueue.main.async {
                            let all = keep.union(pending.compactMap { $0.content.userInfo["questionID"] as? String })
                            self.store.state.questions = self.store.state.questions.filter { all.contains($0.key) }
                            self.store.persist()
                        }
                    }
                }
            }
        }
    }
    func test(completion: @escaping (String) -> Void) {
        let rs = StudyCore.records(store.state.storage)
        let level = store.state.settings.level
        guard let w = words.first(where: { rs[$0.key] != nil && (level == 0 || $0.hsk == level) }),
              let q = StudyCore.question(word: w) else {
            completion("Chưa có từ đã học trong HSK được chọn. Học hoặc đánh dấu một từ trước, rồi thử lại."); return
        }
        center.getNotificationSettings { settings in
            DispatchQueue.main.async {
                guard [.authorized, .provisional, .ephemeral].contains(settings.authorizationStatus) else {
                    completion("Bấm Bật Simple Test và cho phép thông báo trước."); return
                }
                self.add(q, after: 10) { error in DispatchQueue.main.async {
                    completion(error?.localizedDescription ?? "Đã hẹn câu thử sau 10 giây. Khóa màn hình, nhấn giữ thông báo rồi trả lời. Câu thử cũng cập nhật SRS.")
                } }
            }
        }
    }
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification,
                                withCompletionHandler completion: @escaping (UNNotificationPresentationOptions) -> Void) {
        completion([.banner, .list, .sound])
    }
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse,
                                withCompletionHandler completion: @escaping () -> Void) {
        DispatchQueue.main.async {
            guard let id = response.notification.request.content.userInfo["questionID"] as? String,
                  let q = self.store.state.questions[id] else { completion(); return }
            guard ["HSK_TRUE", "HSK_FALSE"].contains(response.actionIdentifier) else {
                self.stateChanged?(); completion(); return
            }
            let selected = response.actionIdentifier == "HSK_TRUE", correct = selected == q.truth
            guard self.store.answer(id: id, selected: selected) else { self.stateChanged?(); completion(); return }
            center.removeDeliveredNotifications(withIdentifiers: [response.notification.request.identifier])
            let feedback = "\(correct ? "✓ Chính xác" : "✗ Chưa đúng"). \(q.han): \(q.correctGloss).\n\n"
            self.reschedule(); self.stateChanged?()
            let settings = self.store.state.settings
            let count = self.store.state.dailyCount[self.store.dayKey()] ?? 0
            let pool = StudyCore.eligible(words: self.words, storage: self.store.state.storage,
                         level: settings.level, at: Date().timeIntervalSince1970 * 1000, excluding: q.key)
            if settings.enabled && settings.nextAfterAnswer && count < settings.limit,
               let w = pool.first, let next = StudyCore.question(word: w) {
                self.add(next, after: 3, prefix: feedback) { _ in completion() }
            } else {
                let c = UNMutableNotificationContent(); c.title = "HSK · Kết quả Simple Test"
                c.body = feedback + "Đã ôn \(count)/\(settings.limit) câu hôm nay. Xem lịch sử trong app."
                c.threadIdentifier = "hsk-simple-test"
                center.add(UNNotificationRequest(identifier: "hsk-feedback", content: c,
                    trigger: UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false))) { _ in completion() }
            }
        }
    }
}

extension StudyStore {
    func lastNotificationError(_ error: Error) {
        // Keep the scheduler failure visible on the next foreground refresh.
        state.answers.append(["han": "Thông báo", "gloss": error.localizedDescription, "correct": "error"])
        state.answers = Array(state.answers.suffix(100)); persist()
    }
}
