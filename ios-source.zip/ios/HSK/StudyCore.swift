import Foundation

struct StudyWord: Codable {
    let key: String
    let han: String
    let pin: String
    let hsk: Int
    let senses: [String]
    // Incorrect glosses use existing quiz distractor rules, not arbitrary translations.
    let distractors: [String]
}

struct QuizItem: Codable {
    let id: String
    let key: String
    let han: String
    let pin: String
    let hsk: Int
    let gloss: String
    let correctGloss: String
    let truth: Bool
}

enum StudyCore {
    static let progressKey = "hsk-flashcards-progress-v1"
    static func records(_ storage: [String: String]) -> [String: [String: Any]] {
        guard let raw = storage[progressKey]?.data(using: .utf8),
              let root = try? JSONSerialization.jsonObject(with: raw) as? [String: Any],
              (root["version"] as? Int) == 1 else { return [:] }
        let source = root["words"] as? [String: [String: Any]] ?? [:]
        return source.filter { _, r in
            let status = r["status"] as? String ?? ""
            return ["known", "unknown"].contains(status) &&
                number(r["due"]).isFinite && number(r["interval"]) >= 0 &&
                number(r["ease"]) >= 1.3 && number(r["reps"]) >= 0
        }
    }
    static func number(_ value: Any?) -> Double { (value as? NSNumber)?.doubleValue ?? .nan }
    static func encode(_ value: Any) -> String? {
        guard JSONSerialization.isValidJSONObject(value),
              let data = try? JSONSerialization.data(withJSONObject: value, options: [.sortedKeys]) else { return nil }
        return String(data: data, encoding: .utf8)
    }
    static func review(_ old: [String: Any], correct: Bool, now: Double) -> [String: Any] {
        var r = old
        let oldEase = number(old["ease"]), oldInterval = number(old["interval"])
        let ease = oldEase.isFinite ? oldEase : 2.5
        let interval = oldInterval.isFinite ? oldInterval : 0
        let reps = (old["reps"] as? Int) ?? 0
        let nextInterval = correct ? (reps == 0 ? 1 : reps == 1 ? 3 : max(1, interval * ease)) : 10.0 / 1440
        r["ease"] = correct ? ease : max(1.3, ease - 0.2)
        r["interval"] = nextInterval
        r["reps"] = correct ? reps + 1 : 0
        r["lapses"] = ((old["lapses"] as? Int) ?? 0) + (correct ? 0 : 1)
        r["due"] = now + (nextInterval * 86_400_000).rounded()
        r["lastReview"] = now
        r["firstLearned"] = old["firstLearned"] ?? old["lastReview"] ?? old["lastMarked"] ?? now
        r["status"] = correct ? "known" : "unknown"
        return r
    }
    static func question(word: StudyWord, forceTruth: Bool? = nil) -> QuizItem? {
        guard let correctGloss = word.senses.randomElement(), !correctGloss.isEmpty else { return nil }
        let truth = forceTruth ?? (word.distractors.isEmpty || Bool.random())
        let gloss = truth ? correctGloss : (word.distractors.randomElement() ?? correctGloss)
        return QuizItem(id: UUID().uuidString, key: word.key, han: word.han, pin: word.pin,
                        hsk: word.hsk, gloss: gloss, correctGloss: correctGloss, truth: truth || word.distractors.isEmpty)
    }
    static func eligible(words: [StudyWord], storage: [String: String], level: Int,
                         at: Double, excluding: String? = nil) -> [StudyWord] {
        let rs = records(storage)
        return words.filter { w in
            guard w.key != excluding, level == 0 || w.hsk == level, let r = rs[w.key] else { return false }
            return number(r["due"]) <= at && !w.senses.isEmpty
        }.sorted { a, b in
            let ra = rs[a.key]!, rb = rs[b.key]!
            let la = (ra["lapses"] as? Int) ?? 0, lb = (rb["lapses"] as? Int) ?? 0
            return la == lb ? number(ra["due"]) < number(rb["due"]) : la > lb
        }
    }
}
