import UIKit
import WebKit
import UniformTypeIdentifiers

@main
final class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    func application(_ application: UIApplication, didFinishLaunchingWithOptions options: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        QuizNotifications.shared.configure()
        let window = UIWindow(frame: UIScreen.main.bounds)
        window.rootViewController = StudyViewController()
        window.makeKeyAndVisible(); self.window = window
        return true
    }
}

final class StudyViewController: UIViewController, WKScriptMessageHandler, WKNavigationDelegate, UIDocumentPickerDelegate {
    private var web: WKWebView!
    private let store = StudyStore.shared
    private var ready = false
    override func viewDidLoad() {
        super.viewDidLoad(); view.backgroundColor = .systemBackground
        let config = WKWebViewConfiguration()
        config.userContentController.add(self, name: "hsk")
        let state = StudyCore.encode(store.bridgeState()) ?? "{}"
        let bootstrap = "window.__HSK_NATIVE_STATE__=\(state);for(const [k,v] of Object.entries(window.__HSK_NATIVE_STATE__.storage||{})){localStorage.setItem(k,v)}"
        config.userContentController.addUserScript(WKUserScript(source: bootstrap, injectionTime: .atDocumentStart, forMainFrameOnly: true))
        web = WKWebView(frame: .zero, configuration: config)
        web.navigationDelegate = self; web.translatesAutoresizingMaskIntoConstraints = false
        web.scrollView.contentInsetAdjustmentBehavior = .never
        view.addSubview(web)
        NSLayoutConstraint.activate([web.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            web.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            web.leadingAnchor.constraint(equalTo: view.leadingAnchor), web.trailingAnchor.constraint(equalTo: view.trailingAnchor)])
        guard let folder = Bundle.main.url(forResource: "Web", withExtension: nil) else { return }
        web.loadFileURL(folder.appendingPathComponent("index.html"), allowingReadAccessTo: folder)
        QuizNotifications.shared.stateChanged = { [weak self] in self?.pushState() }
        NotificationCenter.default.addObserver(self, selector: #selector(foreground), name: UIApplication.didBecomeActiveNotification, object: nil)
    }
    @objc private func foreground() { pushState() }
    private func pushState(_ message: String = "") {
        guard ready else { return }
        var state = store.bridgeState(); state["message"] = message
        guard let json = StudyCore.encode(state) else { return }
        web.evaluateJavaScript("window.hskNative?.applyState(\(json))", completionHandler: nil)
    }
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.frameInfo.isMainFrame, let body = message.body as? [String: Any], let kind = body["type"] as? String else { return }
        switch kind {
        case "ready":
            ready = true
            if let data = StudyCore.encode(body["words"] ?? [])?.data(using: .utf8),
               let words = try? JSONDecoder().decode([StudyWord].self, from: data) { QuizNotifications.shared.words = words }
            pushState(); QuizNotifications.shared.reschedule()
        case "save":
            if let storage = body["storage"] as? [String: String], let revision = body["revision"] as? Int {
                let accepted = store.receive(storage: storage, revision: revision)
                pushState(accepted ? "" : "Đã đồng bộ lại kết quả ôn trên thông báo.")
                if accepted { QuizNotifications.shared.reschedule() }
            }
        case "settings":
            store.state.settings.hour = min(23, max(0, body["hour"] as? Int ?? 20))
            store.state.settings.limit = min(30, max(1, body["limit"] as? Int ?? 10))
            store.state.settings.level = min(6, max(0, body["level"] as? Int ?? 0))
            store.state.settings.nextAfterAnswer = body["nextAfterAnswer"] as? Bool ?? true
            store.persist(); QuizNotifications.shared.reschedule(); pushState("Đã lưu lịch ôn.")
        case "enable": QuizNotifications.shared.enable { [weak self] result in self?.pushState(result) }
        case "disable": QuizNotifications.shared.disable(); pushState("Đã tắt Simple Test.")
        case "test": QuizNotifications.shared.test { [weak self] result in self?.pushState(result) }
        case "export": exportBackup()
        case "import":
            let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.json], asCopy: true)
            picker.delegate = self; present(picker, animated: true)
        default: break
        }
    }
    private func exportBackup() {
        let data: [String: Any] = ["format": "hsk-transfer-v1", "storage": store.state.storage]
        guard let json = StudyCore.encode(data) else { return }
        let file = FileManager.default.temporaryDirectory.appendingPathComponent("hsk-progress.json")
        do { try json.write(to: file, atomically: true, encoding: .utf8) }
        catch { pushState("Không xuất được bản sao lưu."); return }
        let share = UIActivityViewController(activityItems: [file], applicationActivities: nil)
        share.popoverPresentationController?.sourceView = web
        share.popoverPresentationController?.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.midY, width: 1, height: 1)
        present(share, animated: true)
    }
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let url = urls.first else { return }
        let accessing = url.startAccessingSecurityScopedResource()
        defer { if accessing { url.stopAccessingSecurityScopedResource() } }
        guard let data = try? Data(contentsOf: url), data.count < 20_000_000,
              let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              root["format"] as? String == "hsk-transfer-v1",
              let storage = root["storage"] as? [String: String],
              !StudyCore.records(storage).isEmpty else { pushState("File chưa đúng định dạng hoặc chưa có tiến độ hợp lệ."); return }
        let alert = UIAlertController(title: "Nhập tiến độ?", message: "Thay tiến độ trong app bằng bản sao lưu. Website không bị thay đổi.", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Hủy", style: .cancel))
        alert.addAction(UIAlertAction(title: "Nhập", style: .default) { _ in
            self.store.state.storage = storage.filter { $0.key.hasPrefix("hsk-") }
            self.store.state.revision += 1
            self.store.state.questions = [:]; self.store.state.answered = []
            QuizNotifications.shared.center.removeAllDeliveredNotifications()
            guard self.store.persist() else { self.pushState(); return }
            self.pushState("Đã nhập tiến độ. Mở lại app nếu đang có phiên kiểm tra dở.")
            QuizNotifications.shared.reschedule()
        })
        present(alert, animated: true)
    }
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else { decisionHandler(.cancel); return }
        if url.isFileURL { decisionHandler(.allow) }
        else {
            if ["https", "http"].contains(url.scheme ?? "") { UIApplication.shared.open(url) }
            decisionHandler(.cancel)
        }
    }
}
