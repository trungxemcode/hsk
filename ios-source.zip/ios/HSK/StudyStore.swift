import Foundation

struct QuizSettings: Codable {
    var enabled = false
    var hour = 20
    var limit = 10
    var level = 0
    var nextAfterAnswer = true
}

struct SavedStudy: Codable {
    var revision = 0
    var storage: [String: String] = [:]
    var settings = QuizSettings()
    var questions: [String: QuizItem] = [:]
    var answered: [String] = []
    var dailyCount: [String: Int] = [:]
    var answers: [[String: String]] = []
}

final class StudyStore {
    static let shared = StudyStore()
    var state: SavedStudy
    private let file: URL
    private(set) var lastError: String?
    private init() {
        let folder = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        file = folder.appendingPathComponent("hsk-study-v1.json")
        if let data = try? Data(contentsOf: file), let saved = try? JSONDecoder().decode(SavedStudy.self, from: data) {
            state = saved
        } else { state = SavedStudy() }
    }
    @discardableResult func persist() -> Bool {
        do {
            let data = try JSONEncoder().encode(state)
            try data.write(to: file, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
            lastError = nil
            return true
        } catch { lastError = "Không lưu được tiến độ: \(error.localizedDescription)"; return false }
    }
    func receive(storage: [String: String], revision: Int) -> Bool {
        guard revision == state.revision else { return false }
        state.storage = storage.filter { $0.key.hasPrefix("hsk-") }
        state.revision += 1
        return persist()
    }
    func dayKey() -> String {
        let f = DateFormatter(); f.calendar = Calendar(identifier: .gregorian)
        f.timeZone = TimeZone.current; f.dateFormat = "yyyy-MM-dd"
        return f.string(from: Date())
    }
    @discardableResult func answer(id: String, selected: Bool) -> Bool {
        guard !state.answered.contains(id), let q = state.questions[id] else { return false }
        let now = Date().timeIntervalSince1970 * 1000, correct = selected == q.truth
        var records = StudyCore.records(state.storage)
        guard let old = records[q.key] else { return false }
        records[q.key] = StudyCore.review(old, correct: correct, now: now)
        state.storage[StudyCore.progressKey] = StudyCore.encode(["version": 1, "words": records])
        state.answered.append(id); state.answered = Array(state.answered.suffix(500))
        state.questions.removeValue(forKey: id)
        let day = dayKey(); state.dailyCount[day, default: 0] += 1
        state.dailyCount = state.dailyCount.filter { $0.key >= String(day.prefix(7)) }
        state.answers.append(["han": q.han, "gloss": q.gloss, "correctGloss": q.correctGloss,
                              "correct": correct ? "1" : "0", "truth": q.truth ? "1" : "0",
                              "time": String(Int(now))])
        state.answers = Array(state.answers.suffix(100))
        updateAdaptive(key: q.key, correct: correct, now: now)
        state.revision += 1
        return persist()
    }
    private func updateAdaptive(key: String, correct: Bool, now: Double) {
        let storageKey = "hsk-adaptive-learning-v1"
        var root: [String: Any] = ["version": 1, "enabled": true, "stats": [String: Any]()]
        if let data = state.storage[storageKey]?.data(using: .utf8),
           let parsed = try? JSONSerialization.jsonObject(with: data) as? [String: Any] { root = parsed }
        var stats = root["stats"] as? [String: [String: Any]] ?? [:]
        let id = StudyCore.encode([key, "han"])!
        var r = stats[id] ?? ["key": key, "type": "han", "attempts": 0, "wrong": 0, "streak": 0]
        r["attempts"] = ((r["attempts"] as? Int) ?? 0) + 1
        r["wrong"] = ((r["wrong"] as? Int) ?? 0) + (correct ? 0 : 1)
        r["streak"] = correct ? ((r["streak"] as? Int) ?? 0) + 1 : 0
        r["last"] = now; stats[id] = r; root["stats"] = stats
        state.storage[storageKey] = StudyCore.encode(root)
    }
    func bridgeState() -> [String: Any] {
        ["revision": state.revision, "storage": state.storage,
         "settings": ["enabled": state.settings.enabled, "hour": state.settings.hour,
                      "limit": state.settings.limit, "level": state.settings.level,
                      "nextAfterAnswer": state.settings.nextAfterAnswer],
         "answers": Array(state.answers.suffix(20)), "error": lastError ?? ""]
    }
}
