import Foundation

@main struct CoreTests {
    static func main() {
        let old: [String: Any] = ["status":"unknown", "ease":2.5, "interval":0, "reps":0, "lapses":0, "due":0]
        let a = StudyCore.review(old, correct: true, now: 1000)
        assert(StudyCore.number(a["due"]) == 86_401_000)
        assert((a["status"] as? String) == "known")
        let b = StudyCore.review(a, correct: true, now: 2000)
        assert(StudyCore.number(b["interval"]) == 3)
        let c = StudyCore.review(b, correct: false, now: 3000)
        assert(StudyCore.number(c["due"]) == 603_000)
        assert((c["reps"] as? Int) == 0 && (c["lapses"] as? Int) == 1)
        let word = StudyWord(key:"1|爱|ài", han:"爱", pin:"ài", hsk:1, senses:["yêu","dễ/hay"], distractors:["ăn"])
        let trueQ = StudyCore.question(word: word, forceTruth: true)!
        let falseQ = StudyCore.question(word: word, forceTruth: false)!
        assert(trueQ.truth && word.senses.contains(trueQ.gloss))
        assert(!falseQ.truth && falseQ.gloss == "ăn")
        let storage = [StudyCore.progressKey:StudyCore.encode(["version":1,"words":[word.key:old]])!]
        assert(StudyCore.eligible(words:[word], storage:storage, level:1, at:1).count == 1)
        assert(StudyCore.eligible(words:[word], storage:storage, level:2, at:1).isEmpty)
        assert(StudyCore.eligible(words:[word], storage:[:], level:0, at:1).isEmpty)
        print("PASS: SRS intervals, wrong answer, true/false senses, learned-only and level filtering")
    }
}
